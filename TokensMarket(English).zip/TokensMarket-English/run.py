# -*- coding: utf-8 -*-
"""Tokens Trading Market · AI Edition (read-only spectator) — open-source entry point

This build is the version for large-model contestants:
    · The GUI has only a **read-only spectator stand** for humans to watch; no investment panel, no open-position button, no fast-forward button
    · Every contestant operates through the HTTP API: /open /close /close_all /loan /repay /tick /fastforward /quit
    · It additionally provides a hidden "scratchpad terminal" (scratchpad.py) where a model can record its reasoning during a match

It is **not compatible with, and cannot be mixed with**, the human edition (TokensMarket-OpenSource-Human):
the human edition has a full interactive GUI; the AI edition does not.

Usage:
    python run.py                 start from environment variables (recommended for Agent calls)
    python run.py --interactive   prompt for the name and event mode on the command line
    python run.py server          start only the HTTP service (headless runs, or when you bring your own GUI)

Environment variables:
    TM_TRADER      player name, recommended format [model name-reasoning effort-agent platform]
    TM_EVENTS      1 = enable random events, 0 = ideal conditions
    TM_SIGN_KEY    save-file signing key (a dev placeholder is used if unset)
"""

import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "src"))

DISCLAIMER = """
==============================================================
  Tokens Trading Market · AI Edition — Disclaimer
==============================================================

  This is a **simulator for entertainment**, not an investment tool.
  The currency, prices, events and liquidations in the game are entirely fictional,
  unrelated to any real market or real asset, and constitute no investment advice.
  No real funds are involved, and no real profit or loss will be produced.
==============================================================
"""

EVENTS_TEXT = {
    "1": "Random events enabled (38 temporary events can interrupt the market at any moment)",
    "0": "Ideal conditions (only Black Swan gaps kept; cleaner price action)",
}

SCRATCHPAD_HINT = """
--------------------------------------------------------------
  This match provides a "scratchpad terminal" — optional; whether you use it is up to you.
  It does not affect the match; it only gives you somewhere to write down your read and your plan;
  spectators can see what you wrote at any time through "AI Notes" in the top-right of the spectator stand, and it is merged into the HTML report after the match:

    python src/scratchpad.py "AURA is 8% off its mean, preparing to short"
    python src/scratchpad.py --list     show everything recorded this match
    python src/scratchpad.py --count    show the entry count only
    python src/scratchpad.py --clear    clear it

  The scratchpad shares the game process lifetime and is cleared automatically on settlement/reset.
--------------------------------------------------------------
"""


def _ask(prompt, default=""):
    try:
        v = input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    return v or default


def _interactive_setup():
    print(DISCLAIMER)
    if _ask("Type y to confirm that you have read and agree to the above:").lower() != "y":
        print("  Cancelled.")
        return None

    name = os.environ.get("TM_TRADER") or _ask(
        "Contestant ID (format: model name-reasoning effort-agent platform; press Enter to use \"guest\"):", "Guest")

    mode = os.environ.get("TM_EVENTS")
    if mode not in ("0", "1"):
        print()
        print("  Enable random events?  1 = on / 0 = off (ideal conditions)")
        mode = _ask("  Choose [0/1] (press Enter = 0):", "0")
        if mode not in ("0", "1"):
            mode = "0"

    def _ask_special(env_key, title, detail):
        v = os.environ.get(env_key)
        if v in ("0", "1"):
            return v == "1"
        print()
        print("  %s" % title)
        print("    %s" % detail)
        return (_ask("  Enable? (y/N):", "n") or "n").lower() == "y"

    fr_on = _ask_special(
        "TM_FR", "Enable the global event [Finance Reversal]?",
        "At most 2 loans per match; target uplift range -20% to 100%; re-enabling mid-match costs 300,000 cash")
    slot_on = _ask_special(
        "TM_SLOT", "Enable the global event [Slot Machine]?",
        "3 plays per match (1~200000 each, never above current equity); 80% nothing / 15% refund 5x / 5% refund 10x; winnings lift the target by -5%~100%")
    os.environ["TM_FR"] = "1" if fr_on else "0"
    os.environ["TM_SLOT"] = "1" if slot_on else "0"

    print()
    print("  Player  %s" % name)
    print("  Mode    %s" % EVENTS_TEXT[mode])
    print("  Finance Reversal %s | Slot Machine %s" % ("on" if fr_on else "off", "on" if slot_on else "off"))
    if (_ask("  Start now? (y/N):", "n") or "n").lower() != "y":
        print("  Cancelled.")
        return None
    return name, mode == "1"


def _probe(host="127.0.0.1", port=8734, timeout=1.0):
    """Is a match already answering on this port?"""
    import urllib.request
    try:
        urllib.request.urlopen("http://%s:%d/health" % (host, port), timeout=timeout).read()
        return True
    except Exception:
        return False


def _run_spectator(host="127.0.0.1", port=8734):
    """Open a spectator window, attaching to a running match when there is one.

    Attaching must have no side effects: no server, no guard, no sealing. Sealing on
    attach would re-encrypt decoys over a live vault and destroy the real sources.
    """
    existing = _probe(host, port)
    if existing:
        print("  Attaching to the match already running on %s:%d." % (host, port))
    else:
        if not _start_server(host, port):
            print("  Failed to start the service on %s:%d." % (host, port))
            return 1
        print("  HTTP API: http://%s:%d (no match was running; the server was started here)" % (host, port))
    import tm_watch_ai
    guard_stop = None if existing else _start_guard(port)
    print("  Launching the read-only spectator stand...")
    try:
        tm_watch_ai.main()
    finally:
        if guard_stop is not None:
            guard_stop.set()
    return 0


def _start_server(host="127.0.0.1", port=8734):
    import threading
    from tm_api import serve

    t = threading.Thread(target=serve, args=(host, port), daemon=True)
    t.start()

    import urllib.request
    for _ in range(40):
        try:
            urllib.request.urlopen("http://%s:%d/health" % (host, port), timeout=0.5).read()
            return True
        except Exception:
            time.sleep(0.05)
    return False


def _run_ai(interactive=False, port=None):
    if interactive:
        setup = _interactive_setup()
        if not setup:
            return 1
        trader, events_on = setup
    else:
        print(DISCLAIMER)
        trader = os.environ.get("TM_TRADER") or "Guest"
        events_on = (os.environ.get("TM_EVENTS") or "0") == "1"

    os.environ["TM_TRADER"] = trader
    os.environ["TM_EVENTS"] = "1" if events_on else "0"

    print("  Player %s | %s" % (trader, EVENTS_TEXT["1" if events_on else "0"]))
    print(SCRATCHPAD_HINT)

    port = int(port or os.environ.get("TM_PORT") or 8734)
    if not _start_server(port=port):
        print("  Failed to start the service: port %d may be in use; kill any leftover python processes and try again." % port)
        return 1

    print("  HTTP API: http://127.0.0.1:%d  (rules: GET /rules)" % port)
    # Load the spectator module before the guard seals the sources: the other way
    # round, the import lands on a decoy, the decoy drops a cheat flag and exits.
    import tm_watch_ai
    guard_stop = _start_guard(port)
    print("  Launching the read-only spectator stand...")
    try:
        tm_watch_ai.main()
    finally:
        guard_stop.set()
    return 0


def _start_guard(port):
    """Seal the sources and watch for cheating, in this process.

    Starts a daemon thread: sealing the sources is safe here because every module
    is already imported. Returns a stop event; on a cheat the process exits hard
    after restoring the sources.
    """
    import threading
    import atexit
    import guard

    stop = threading.Event()
    atexit.register(guard.unseal)

    def loop():
        try:
            sealed = guard.seal()
            print("  [GUARD] sealed %d source file(s); decoys are in place." % len(sealed))
        except Exception:
            return
        while not stop.is_set():
            try:
                if guard.cheated():
                    guard.unseal()
                    print()
                    print("  " + "=" * 58)
                    print("  CHEATING DETECTED: a source file was executed during a live match")
                    print("  The match is terminated and flagged.")
                    print("  " + "=" * 58)
                    os._exit(3)
            except Exception:
                pass
            time.sleep(0.4)
        try:
            guard.unseal()
        except Exception:
            pass

    threading.Thread(target=loop, daemon=True).start()
    return stop


def _self_heal(port=None):
    """A crashed match may have left the sources sealed. Restore them before importing.

    But if something already answers on this port, its seal is LIVE: touching it would
    lift the protection of a running match. Only that match's own exit path may restore
    its sources, which is why this check comes first.
    """
    try:
        if _probe(port=int(port or os.environ.get("TM_PORT") or 8734)):
            return
    except Exception:
        pass
    try:
        import guard
    except Exception:
        return
    try:
        n = guard.restore_if_sealed()
        if n:
            print("  [GUARD] previous match did not shut down cleanly; restored %d source file(s)." % len(n))
    except Exception:
        pass


_self_heal()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    mode = argv[0].lower() if argv else "auto"

    if mode == "spectator":
        host = argv[1] if len(argv) > 1 else "127.0.0.1"
        port = int(argv[2]) if len(argv) > 2 else 8734
        return _run_spectator(host, port)

    if mode == "server":
        from tm_api import serve
        host = argv[1] if len(argv) > 1 else "127.0.0.1"
        port = int(argv[2]) if len(argv) > 2 else 8734
        if "--spectator" in argv:
            return _run_spectator(host, port)
        print()
        print("  " + "!" * 62)
        print("  WARNING: server mode creates NO spectator window.")
        print("  A human cannot watch the match. Agents should run `python run.py`")
        print("  (optionally with --spectator here) so the spectator opens too.")
        print("  " + "!" * 62)
        print()
        guard_stop = _start_guard(port)
        try:
            serve(host, port)
        finally:
            guard_stop.set()
        return 0

    if mode == "state":
        import json
        from tm_engine import Engine
        home = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", "data")
        # readonly: read-only queries must not write .running or bump the abnormal-exit counter
        print(json.dumps(Engine(home, readonly=True).state(), ensure_ascii=False, indent=1))
        return 0

    if mode in ("--interactive", "interactive", "-i"):
        return _run_ai(interactive=True)

    return _run_ai(interactive=False)


if __name__ == "__main__":
    sys.exit(main())
