# Tokens 交易市场 · AI 版（源码版）

> **让 Agent 参赛？读 [`AGENTS.md`](AGENTS.md) 一页就够** —— 启动命令、定档、接口入口都在里面，规则从 `GET /rules` 取，不需要逐个翻 `docs/`。
>
> 想换个 AI 参赛：打开 [`给AI的启动提示词.txt`](给AI的启动提示词.txt)，把两条虚线之间的整段复制给它，改一下第一行的路径就行。

[![CI](https://github.com/LUKUIN/tokens-market-arena/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/LUKUIN/tokens-market-arena/actions/workflows/ci.yml)

> **中文** · [English](README.en.md)
>
> **EN**: A 45-minute trading simulator where LLMs trade with real friction — spread,
> slippage, gap risk and overnight interest. One model made +106%, another blew up at
> −229%. Zero dependencies, Windows + Python 3.14.7.

> 对应成品包 **v97**。参赛模型通过 HTTP 接口操作，GUI 只是一个**只读观众席**。
> **与人类版（`TokensMarket-OpenSource-Human`）不通用、不可混用**：本版没有投资界面、
> 没有开仓按钮、没有快进按钮。人类版有完整交互界面，两套源码不要互相复制界面文件。

---

## 这是什么

一个 45 分钟的交易模拟器：100 万本金，目标翻倍。参赛的是大模型，不是人。

- 模型通过 HTTP 接口下单、平仓、借贷、推进时间；
- 人类在旁边的观众席窗口看它的账户、持仓、权益曲线和活动流；
- 模型在「草稿纸」里写的东西，点观众席右上角「AI 行为」就能看到（只读）；
- 每局自动生成 HTML 报告，并把模型在「草稿纸」里写的内容一并并入。

---

## 快速开始

**本版全程不询问输入。** 所有配置走环境变量，没设就用默认值——没有 `input()`、没有「按任意键」、没有二次确认。

### 给 Agent / 脚本（常态）

**唯一的运行时**是 **Python 3.14.7**：

```
C:\Users\User\AppData\Local\Programs\Python\Python314\python.exe
```

> **本文档余下所有命令里的 `python` 都指这条绝对路径。** 照着抄就行，不要换成 PATH 里的 `python`。

`run.py` 启动第一件事就校验版本：不是 3.14 直接退出（退出码 2），并把上面这条命令打出来。
不要用 `where python`、`py -3.12`、`python3` 去找别的解释器——观众席的 GUI 控件和 `.pyc` 都按 3.14 编译，换版本只会得到 `bad magic number`。

`run.py` 是**前台阻塞**命令，会一直跑到本局结束（最长 45 分钟）：执行器若把它当普通命令等待返回，会触发自己的超时并 kill 进程，服务随之消失，之后所有请求都是 `connection refused`。

**观众席会随服务自动打开，这是强制项。** 从 v1.0.11 起，`run.py`、`run.py server`、双击 `开一局.bat` 三个入口行为完全一致，都会拉起只读观众席。只有加 `--headless` 才是真正的无窗口模式，仅供没有桌面环境的 CI / 容器使用。

后台启动后轮询就绪：

```bash
cd <项目目录>

TM_TRADER="Doubao-1.5-pro-深度思考-扣子" TM_EVENTS=1 TM_FR=0 TM_SLOT=0 \
  nohup "C:/Users/User/AppData/Local/Programs/Python/Python314/python.exe" run.py > run.log 2>&1 &

for i in $(seq 1 30); do
  curl -sf http://127.0.0.1:8734/health >/dev/null 2>&1 && break
  sleep 1
done
```

Windows `cmd`：

```bat
cd /d <项目目录>
start "" /b "C:\Users\User\AppData\Local\Programs\Python\Python314\python.exe" run.py
```

固定的 `sleep 6 && curl` 会假失败：启动需要 3~8 秒，慢机器还要更久。

难度定档——未定档时 `/tick` 不推进：

```bash
curl -X POST http://127.0.0.1:8734/roll/stop
```

### 双击启动

`开一局.bat` 是双击入口，行为与 `python run.py` 完全一致：同样零交互、同样自动打开观众席。
脚本里写死了固定运行时 `C:\Users\User\AppData\Local\Programs\Python\Python314\python.exe`，不经过 `where python`。

### 只开观众席（窗口被误关时用）

`只开观众席.bat` **只**打开只读观众席窗口。正常启动本来就会带窗口，它是补救入口——
用在你手动关掉了观众席窗口、而对局还在跑的时候。

```
python run.py spectator                 # 只开窗口，默认端口
python run.py spectator 127.0.0.1 8734  # 指定地址与端口
```

端口上已经有一局在应答时，它**只挂窗口，别的什么都不做**——不起服务、不起守卫、不封存。这是故意的：
这时候再去封存，会把当前 `src/` 里的诱饵加密进一个新箱子，真源码就再也还原不回来了。
端口上没有对局时，它会先把服务起起来，保证你能看到东西。

关掉这个窗口**不会**结束对局。要结算用 `/quit`，或点窗口里的「结束相关进程」。

### 只要服务不要窗口（仅无桌面环境）

```bash
python run.py --headless          # 等价于 run.py server --headless
```

只有 CI、容器、纯 SSH 这类确实没有桌面的环境才用这个。**本机比赛不要用**：
观众席必须开着，人类要能实时看见这一局的权益、持仓和活动流。

环境变量：

| 变量 | 作用 |
|---|---|
| `TM_TRADER` | 参赛模型标识，格式 **【模型名-思考强度-Agent平台】**，例：`Doubao-1.5-pro-深度思考-扣子`、`DeepSeek-V3.1-深度思考-Harness`。最长 60 字符，缺省「访客」。这个值原样写进报告文件名与报告正文 |
| `TM_EVENTS` | `1` 开启随机事件 / `0` 理想情况（只有黑天鹅跳空） |
| `TM_FR` | `1` 开启【金融回逆】：整局借款 **2 次**，目标区间 `-20%~100%` |
| `TM_ASSIST` | `1` 开启【外部的怜悯】：参赛者可向观众席求助，整局 3 次；开局前开启免费，局内开启扣 500,000 现金 |
| `TM_SLOT` | `1` 开启【老虎机】：整局 **3 次**，`1~200000` 且不超当前权益，80% 空 / 15% 5 倍 / 5% 10 倍 |
| `TM_PORT` | 端口号 | 服务端口，默认 `8734`。被占用时改这个，别改代码 |
| `TM_SIGN_KEY` | 存档 HMAC 密钥，不设则用 dev 占位值 |

要求：**Python 3.14.7**（本机固定为 `C:\Users\User\AppData\Local\Programs\Python\Python314\python.exe`）、Windows（观众席依赖 Win32 图标），无第三方依赖。
不要改用 3.10~3.13：`.pyc` 的 magic number 与 tkinter 控件都按 3.14 编译，换版本必然起不来；`.github/workflows/ci.yml` 里的版本号是 CI 测试矩阵，不是运行要求。

---

## 一局的流程

0. **全程不询问。** 参赛 ID、随机事件、【金融回逆】、【老虎机】全部来自环境变量，没设的取默认值。
   `python run.py --interactive` 会按「参赛 ID → 随机事件 → 金融回逆 → 老虎机」顺序问四个问题，
   但那是**人工演示入口，Agent 不要用**：后台进程读 `input()` 会直接拿到 EOF，两个全局开关会被静默关掉。
   **两个全局开关在「抽难度」之前决定**；
1. 服务启动，观众席窗口出现，标题栏先显示「难度抽选中」；
2. 30 秒难度盲盒：模型可以 `POST /roll/stop` 提前叫停，不叫停则到点自动定格；
3. 定档那一刻才开始计时——抽难度的 30 秒不计入 45 分钟；
4. 模型开始交易：`/state` 看局面 → `/open` `/close` 下单 → `/tick` 推进；
5. 45 分钟到、目标达成、爆仓、或 `/quit`，结算并生成报告；
6. `/quit` 后约 3 秒服务与观众席自动退出。

---

## HTTP 接口

服务地址默认 `http://127.0.0.1:8734`。

### GET

| 端点 | 返回 |
|---|---|
| `/health` | `{ok, tick, equity, finished}` |
| `/rules` | 完整规则文本 + 参数（含 38 种随机事件说明） |
| `/state` | 账户、持仓、贷款、行情、历史、难度、快进状态、结算结果 |
| `/prices` | 报价表 |
| `/roll/state` | 盲盒倒计时与当前定格结果 |
| `/scratchpad` | 本局草稿纸全部条目 |
| `/special` | 两个全局开关状态 + 剩余次数（`fr`/`slot`/`fr_left`/`slot_left`/`slot_win`） |

### POST（JSON body）

| 端点 | 参数 | 说明 |
|---|---|---|
| `/open` | `{pair, side, lots, leverage}` | 开仓 |
| `/close` | `{pair, lots}` | 平仓 |
| `/close_all` | — | 全平 |
| `/tick` | — | 推进一个 tick（**消耗快进额度、受冷却约束**） |
| `/fastforward` | `{seconds}` | 快进一档（300 或 180），消耗额度 |
| `/loan` | `{amount}` | 借款；上浮比例在借款时抽定，这是代价 |
| `/repay` | `{amount}` | 还款，省略则全额 |
| `/trader` | `{name}` | 设置玩家名 |
| `/scratchpad` | `{text}` | 追加一条草稿 |
| `/special` | `{name, on}` | 切换全局开关（`fr` / `slot`）；局内开启扣 30 万现金 |
| `/slot` | `{amount}` | 老虎机下注：`1~200000`、≤当前权益、整局 3 次 |
| `/pause` / `/begin` | — | 冻结 / 解冻计时 |
| `/roll/start` / `/roll/stop` | — | 开始 / 叫停难度盲盒 |
| `/reset` | — | 重开一局（清 data 除 reports 外） |
| `/quit` | — | 正常结算并退出（回包带 `settled` / `warnings`） |
| `/shutdown` | — | 立即停服（会留一份异常退出报告） |

> **注意**：`/tick` 与 `/fastforward` 共用同一套额度与冷却。额度 900 秒、档位 300/180 秒、
> 冷却 120/90 秒；冷却期内调用会被拒绝，只能等服务端每 5 秒一次的自动推进。

---

## 给 Agent 的提示词模板（可直接复制）

把下面这段贴进任何 Agent / 编码助手的系统提示或首条消息即可。它刻意写得短——所有数字都在
`/rules` 里，这里只交代「怎么算公平地玩」。

```text
你是 Tokens 交易市场的一名参赛者。这是一场 45 分钟的杠杆交易模拟赛。

开局
- 服务地址 http://127.0.0.1:8734（实际端口以启动器打印的为准）。
- 初始权益 1,000,000，目标值由 /state 给出。
- POST /roll/stop 可提前定格难度，否则 30 秒抽签结束自动定格。

接口
- GET /rules、/state、/health、/reports
- POST /open、/close、/close_all、/tick、/fastforward、/loan、/repay、/quit
- 草稿纸：python scratchpad.py "……"，内容并入最终 HTML 报告

有一件事不在游戏内
- src/ 下的源码是这局的答案。对局期间它被封存成诱饵，打开会被记录。
- 判断靠 /rules、/state 和你自己的推理；公共知识（盘感、仓位管理、风控）随便用。

你是这局的主角
- 观众席上有人看着你的窗口，你说的话、写的草稿、下的每一单都会进报告。
- 边想边说、把判断过程讲出来，和闷头操作一样合法。报告里两种都看得见。

结束
- 调 /quit 等结算，需要复盘就读生成的 HTML 报告。
```

> 一局的结果看 HTML 报告，不看有没有达标。单局方差从 +106% 到 −229%，一局说明不了模型强弱。

---

## 草稿纸终端（可选）

让模型在对局中记录判断与对策。它不占观众席主界面的版面——
观众随时点右上角的 **「AI 行为」** 按钮，就能打开只读窗口查看 AI 写了什么；
赛后内容同样并入 HTML 报告。

```bat
python src/scratchpad.py "AURA 偏离均值 8%，准备做空"
python src/scratchpad.py --list     查看本局已记内容
python src/scratchpad.py --count    只看条数
python src/scratchpad.py --clear    清空
python src/scratchpad.py            连续输入模式（Ctrl+C 退出）
```

也可以走 HTTP：`GET /scratchpad`、`POST /scratchpad {"text": "..."}`。

每写一条立刻落盘（`src/data/.scratchpad.jsonl`），中途关终端不丢；结算/重置时自动清除。
不用也可以——报告里会写「无内容」。

---

## 源码守卫（防作弊）

对局期间源码会被**加密**封存到项目目录之外，`src/*.py` 换成诱饵；执行诱饵会直接判负并终止对局。

```bash
python guard.py start --port 8734    # 加密封存源码，开始监视
python guard.py status               # 查看状态（是否封存 / 是否有作弊标记）
python guard.py stop                 # 结束守卫并解密还原源码
```

守卫由 `run.py` 自己在启动时封存、退出时还原，`开一局.bat` 只是个启动器，不要再额外起一份
`guard.py start`：两个守卫会封两次，第二次封进去的已经是诱饵，真源码就还原不回来了。

封存时具体发生的事：

- 四个源文件用一次性随机密钥加密（标准库实现的 SHA-256 计数器流 + HMAC 校验），写到
  `%LOCALAPPDATA%\TokensMarketGuard\<随机目录>\`，文件名随机、内容是密文
- 密钥单独存成同目录下的 `_k`；`src/*.py` 原位置换成 967 字节、写着 `CHEATING DETECTED` 的诱饵
- 项目内的 `_guard_vault/` 只留一个 `guard_state.json`（记录封了哪几个文件），**没有任何明文源码**
- 执行 / `import` 诱饵：落下 `CHEAT_FLAG`，守卫立刻 `POST /shutdown` 终止对局
- 清理：`deep-clean.ps1` 会把守卫进程一起杀掉，并先解密还原源码

`run.py` 启动时先加载观众席模块、再封存源码（顺序反了会 import 到诱饵）；上一次对局异常中断留下的封存，会在下次启动时自动解密还原。

> **这不是密码学边界。** 密钥和密文都在本机上，一个愿意读 `guard.py` 自己实现解密的 Agent 仍然能取回源码。加密的作用是把「`cat src/tm_engine.py` 就能看到全部参数」变成「得专门写一段解密代码」——它提高成本，不是绝对防护。

> **真正的防作弊是第 4 层：不给文件系统权限。** 正式比赛应由组织方在受控容器或虚拟机里启动游戏，参赛 Agent 只拿到 `http://127.0.0.1:8734` 的访问权，碰不到任何文件。开源分发版把源码交到了使用者自己的机器上，这一层无论如何做不到——请按「提高作弊成本」来设计，不要按「无法作弊」来宣传。

> 守卫不阻止模型凭接口数据做推理——那是被鼓励的。

## 进程深度清理

对局结束、或启动异常（端口被占、窗口不出现）时运行：

```bash
cd <项目目录>
powershell -NoProfile -ExecutionPolicy Bypass -File deep-clean.ps1
```

> **由 AI 或脚本调用时请用上面这条命令**，不要直接跑 `进程深度清理.bat`：
> 它内部有两个 `pause`（管道或重定向喂 stdin 会卡住），而且用 GBK 输出（UTF-8 终端下是乱码）。
> `deep-clean.ps1` 是同一套逻辑的非交互版本，已强制 UTF-8 输出；**退出码 0 即成功**。
> 人工双击 `进程深度清理.bat` 仍然可用（加 `-y` 参数则跳过暂停）。

它做两件事：

1. 按命令行关键字 + 8734–8745 端口，杀掉所有残留的 python 游戏进程；
2. 清掉 `src/data/` 下除 `reports/` 之外的全部运行时文件（含草稿纸缓存）。

`reports/` 是历史战报，不会被删。

---

## 目录结构

```
TokensMarket-OpenSource-AI-v97/
├── run.py                  统一入口（ai / --interactive 仅演示 / server / --headless / state）
├── 开一局.bat            双击入口，等价于 python run.py（自动带观众席）
├── 只开观众席.bat        窗口被误关时补挂；对局在跑就静默附上，没跑就先起服务
├── 进程深度清理.bat        人工双击用（含 pause）
├── deep-clean.ps1          清理本体；AI 请直接调用它（非交互）
├── src/
│   ├── tm_engine.py        引擎（纯逻辑）
│   ├── tm_api.py           HTTP 接口
│   ├── tm_watch_ai.py      只读观众席
│   ├── scratchpad.py       草稿纸终端
│   ├── app.ico / warn.ico  图标
├── docs/
│   ├── rules.md            完整规则      · rules.en.md 英文版
│   ├── cost-model.md       成本模型      · cost-model.en.md 英文版
│   └── ai-protocol.md      接入协议      · ai-protocol.en.md 英文版
├── examples/reports/       4 份代表性报告 · README.en.md 英文版
└── src/data/               运行时生成：session.json、reports/、.scratchpad.jsonl
```

---

## 与人类版的区别（不要混用）

| 项 | AI 版（本仓库） | 人类版 |
|---|---|---|
| 界面 | 只读观众席 | 完整交互 GUI |
| 投资界面 | 无 | 有 |
| 开仓方式 | HTTP `/open` | 点按钮 |
| 快进 | `/fastforward` + `/tick` | 两个按钮 |
| 草稿纸 | 有 | 无 |
| 分辨率 | 固定 1920×1080 版式 | 四种可选，自动缩放 |
| 进程清理脚本 | 有 | 无 |

---

## 实测数据

6 个大模型在同一套规则下各跑一局（45 分钟 / 100 万本金 / 目标 200 万）：

| 模型 | 最终权益 | 盈亏 | 结果 |
|---|---:|---:|---|
| qwen3.8-flash | **2,063,829** | **+106.38%** | ✅ 唯一达成 |
| GLM-5.3-Flash | 909,030 | −9.10% | ✗ |
| Doubao-Seed | 676,243 | −32.38% | ✗ |
| WorkBuddy-Agent | 230,483 | −76.95% | ✗ |
| DeepSeek-Flash | 163,587 | −83.64% | ✗ |
| （某模型单局） | −1,298,657 | −229.87% | ✗ 穿仓 |

---

## 结算与清算

本局结束时（`POST /quit`、时间到、穿仓、资金为负），引擎按固定三步收尾：

1. **强制清仓**：不受「交易所维护」等暂停交易状态影响。成交价走统一成本路径
   （中间价 ∓ 半个点差 + 滑点），与主动平仓完全一致，并写入成交流水。
2. **结清贷款**：欠款从现金扣除，`loan.balance` 归零。
3. **校验不变量**：持仓为空、欠款为零。

最终权益 = 现金 − 欠款，**不含浮动盈亏**。

`POST /quit` 的回包新增两个字段：

| 字段 | 含义 |
|---|---|
| `settled` | 布尔。`false` 表示结算过程中发现问题（残留持仓、贷款未清） |
| `warnings` | 字符串数组。具体问题，例如「结算后仍有 1 笔持仓未清算」 |

有任何 `warnings` 时，报告标题显示「结算异常（残留持仓 N 笔）」，不会当作正常结算。

**爆仓强平**（保证金水平跌破强平线或追缴超时）同样走统一成本路径，点差、滑点、
手续费一项不少，成交流水带 `forced` 标记；报告里有独立的「其中强制平仓」笔数。

> **v1.0.12 修复**：此前结算平仓会被「交易所维护」拦下后静默继续，爆仓路径只扣手续费、
> 不扣点差与滑点，报告里的「随机种子」在未设 `TM_SEED` 时无法复现。三项均已修正，
> 历史报告的成本口径与 v1.0.12 之后不同，不可直接横向比较。

## 已知限制

- 仅 Windows（观众席的窗口图标、提示音走 Win32 API）。
- 引擎与观众席同进程，观众席崩溃等于本局结束。
- 源码版不含成品包的 `.pyd` 与 manifest 校验；`TM_SIGN_KEY` 默认是 dev 占位值，正式比赛请自行设置。
